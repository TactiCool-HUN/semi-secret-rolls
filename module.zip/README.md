This module has been inspired by reddit user u/Ahaskins [post](https://www.reddit.com/r/Pathfinder2e/comments/1230ox7/house_rule_alternative_to_secret_rolls_the/) about rolling 4 public dice to rolls secret rolls, from which only the GM knows which one is the true one.

I plan on adding the following features after some play-testing with my players:
- Changing who's rolls are effected (for now only player rolls are).
- Ability to change how many dice are rolled.
- Ability to change who sees the 4 (or however many) rolls.

If you have other suggestions please let me know!

This is basically the first gitHub repo I have that is meant to be actively public facing so sorry if something is off!

Currently only a test version is available through this manifest url: https://github.com/TactiCool-HUN/semi-secret-rolls/releases/download/0.1.1/module.json
